#ifndef STATE_ENUMS_H
#define STATE_ENUMS_H

enum State {
    IDLE,
    MOVING,
    TURNING,
    STOPPED,
    OVERLINE
};

#endif