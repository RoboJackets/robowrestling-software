#ifndef UTIL_H
#define UTIL_H

class util {
    public:
       static int average(int values[], int size);
};

#endif